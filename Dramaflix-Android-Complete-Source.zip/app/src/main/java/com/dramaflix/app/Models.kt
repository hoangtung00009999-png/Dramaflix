package com.dramaflix.app

import org.json.JSONArray
import org.json.JSONObject

data class Episode(val title: String, val videoUrl: String)
data class Season(val title: String, val episodes: List<Episode>)
data class Film(
    val id: String,
    val title: String,
    val description: String = "",
    val poster: String = "",
    val category: String = "",
    val year: String = "",
    val type: String = "movie",
    val videoUrl: String = "",
    val seasons: List<Season> = emptyList(),
    val source: String = "Thủ công"
)
data class FilmSource(val name: String, val websiteUrl: String, val catalogUrl: String = "")

object CatalogParser {
    fun parse(raw: String, sourceName: String): List<Film> {
        val root = raw.trim()
        val arr = if (root.startsWith("[")) JSONArray(root)
                  else JSONObject(root).optJSONArray("movies")
                      ?: JSONObject(root).optJSONArray("films")
                      ?: JSONArray()
        val result = mutableListOf<Film>()
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            val seasons = mutableListOf<Season>()
            val seasonArray = o.optJSONArray("seasons") ?: JSONArray()
            for (s in 0 until seasonArray.length()) {
                val so = seasonArray.optJSONObject(s) ?: continue
                val eps = mutableListOf<Episode>()
                val ea = so.optJSONArray("episodes") ?: JSONArray()
                for (e in 0 until ea.length()) {
                    val eo = ea.optJSONObject(e) ?: continue
                    val url = eo.optString("videoUrl").ifBlank { eo.optString("url") }
                    if (url.isNotBlank()) eps.add(Episode(eo.optString("title", "Tập ${e+1}"), url))
                }
                seasons.add(Season(so.optString("title", "Mùa ${s+1}"), eps))
            }
            val id = o.optString("id").ifBlank { "${sourceName}_${i}_${o.optString("title")}" }
            result.add(Film(
                id = id,
                title = o.optString("title", "Chưa có tên"),
                description = o.optString("description"),
                poster = o.optString("poster"),
                category = o.optString("category"),
                year = o.optString("year"),
                type = o.optString("type", if (seasons.isNotEmpty()) "series" else "movie"),
                videoUrl = o.optString("videoUrl"),
                seasons = seasons,
                source = sourceName
            ))
        }
        return result
    }

    fun encode(films: List<Film>): String {
        val arr = JSONArray()
        films.forEach { f ->
            val o = JSONObject()
            o.put("id", f.id); o.put("title", f.title); o.put("description", f.description)
            o.put("poster", f.poster); o.put("category", f.category); o.put("year", f.year)
            o.put("type", f.type); o.put("videoUrl", f.videoUrl)
            val sa = JSONArray()
            f.seasons.forEach { s ->
                val so = JSONObject(); so.put("title", s.title)
                val ea = JSONArray()
                s.episodes.forEach { e -> ea.put(JSONObject().put("title", e.title).put("videoUrl", e.videoUrl)) }
                so.put("episodes", ea); sa.put(so)
            }
            o.put("seasons", sa); arr.put(o)
        }
        return arr.toString(2)
    }
}
