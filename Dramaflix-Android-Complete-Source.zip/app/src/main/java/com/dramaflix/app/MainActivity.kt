package com.dramaflix.app

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection
import java.net.URL
import org.json.JSONArray
import org.json.JSONObject
import coil.compose.AsyncImage

private val Bg = Color(0xFF101014)
private val Panel = Color(0xFF202027)
private val Red = Color(0xFFE50914)
private val White = Color(0xFFF5F5F5)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { DramaflixApp(
            onOpenWebsite = { url -> startActivity(Intent(this, BrowserActivity::class.java).putExtra("url", url)) },
            onPlay = { film, url -> startActivity(Intent(this, PlayerActivity::class.java).putExtra("title", film).putExtra("url", url)) }
        ) }
    }
}

@Composable
private fun DramaflixApp(onOpenWebsite: (String) -> Unit, onPlay: (String, String) -> Unit) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val prefs = remember { context.getSharedPreferences("dramaflix", 0) }
    val scope = rememberCoroutineScope()
    var films by remember { mutableStateOf(runCatching { CatalogParser.parse(prefs.getString("manual_json", "[]") ?: "[]", "Thủ công") }.getOrDefault(emptyList())) }
    var sources by remember {
        mutableStateOf(runCatching {
            val a = JSONArray(prefs.getString("sources", "[]"))
            (0 until a.length()).map { val o=a.getJSONObject(it); FilmSource(o.optString("name"),o.optString("websiteUrl"),o.optString("catalogUrl")) }
        }.getOrDefault(listOf(FilmSource("KhoPhim", "https://khophim.org", ""))))
    }
    var favorites by remember { mutableStateOf(prefs.getStringSet("favorites", emptySet())?.toSet() ?: emptySet()) }
    var tab by remember { mutableStateOf("Trang chủ") }
    var query by remember { mutableStateOf("") }
    var selected by remember { mutableStateOf<Film?>(null) }
    var showAddFilm by remember { mutableStateOf(false) }
    var showAddSource by remember { mutableStateOf(false) }
    var showJson by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf("Sẵn sàng") }
    var jsonText by remember { mutableStateOf("") }
    var sourceName by remember { mutableStateOf("") }
    var websiteUrl by remember { mutableStateOf("") }
    var catalogUrl by remember { mutableStateOf("") }
    var filmTitle by remember { mutableStateOf("") }
    var filmDesc by remember { mutableStateOf("") }
    var filmPoster by remember { mutableStateOf("") }
    var filmVideo by remember { mutableStateOf("") }
    var filmType by remember { mutableStateOf("movie") }
    var filmCategory by remember { mutableStateOf("") }

    fun saveFilms() {
        val manual = films.filter { it.source == "Thủ công" }
        prefs.edit().putString("manual_json", CatalogParser.encode(manual)).apply()
    }
    fun saveSources() {
        val a = JSONArray()
        sources.forEach { a.put(JSONObject().put("name",it.name).put("websiteUrl",it.websiteUrl).put("catalogUrl",it.catalogUrl)) }
        prefs.edit().putString("sources",a.toString()).apply()
    }
    fun refreshSource(s: FilmSource) {
        if (s.catalogUrl.isBlank()) { status = "${s.name}: chưa có địa chỉ API/JSON. Bạn vẫn có thể mở website."; return }
        scope.launch {
            status = "Đang tải ${s.name}..."
            try {
                val raw = withContext(Dispatchers.IO) {
                    val c = (URL(s.catalogUrl).openConnection() as HttpURLConnection)
                    c.connectTimeout = 12000; c.readTimeout = 12000
                    c.setRequestProperty("Accept", "application/json")
                    try { c.inputStream.bufferedReader().use { it.readText() } } finally { c.disconnect() }
                }
                val loaded = CatalogParser.parse(raw, s.name)
                films = (films.filterNot { it.source == s.name } + loaded).distinctBy { it.id }
                status = "Đã tải ${loaded.size} mục từ ${s.name}"
            } catch (e: Exception) { status = "Không tải được: ${e.localizedMessage ?: "lỗi kết nối"}" }
        }
    }

    MaterialTheme(colorScheme = darkColorScheme(
        background = Bg, surface = Panel, primary = Red, onPrimary = White,
        onBackground = White, onSurface = White
    )) {
        Scaffold(
            containerColor = Bg,
            topBar = {
                Column(Modifier.background(Bg).padding(horizontal = 18.dp, vertical = 12.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("DRAMA", color = Red, fontWeight = FontWeight.Black, style = MaterialTheme.typography.headlineMedium)
                        Text("FLIX", color = White, fontWeight = FontWeight.Black, style = MaterialTheme.typography.headlineMedium)
                        Spacer(Modifier.weight(1f))
                        Icon(Icons.Default.VideoLibrary, contentDescription = null, tint = Red)
                    }
                    Text(status, color = Color.LightGray, style = MaterialTheme.typography.labelSmall)
                }
            },
            bottomBar = {
                NavigationBar(containerColor = Panel) {
                    listOf("Trang chủ", "Tìm kiếm", "Yêu thích", "Nguồn", "Thư viện").forEach { item ->
                        NavigationBarItem(
                            selected = tab == item,
                            onClick = { tab = item },
                            icon = {
                                Icon(when(item) {
                                    "Trang chủ" -> Icons.Default.Home
                                    "Tìm kiếm" -> Icons.Default.Search
                                    "Yêu thích" -> Icons.Default.Favorite
                                    "Nguồn" -> Icons.Default.Language
                                    else -> Icons.Default.VideoLibrary
                                }, contentDescription = item)
                            },
                            label = { Text(item) },
                            colors = NavigationBarItemDefaults.colors(selectedIconColor = Red, indicatorColor = Color(0xFF492026), selectedTextColor = White, unselectedTextColor = Color.LightGray)
                        )
                    }
                }
            }
        ) { padding ->
            Column(Modifier.padding(padding).fillMaxSize().padding(horizontal = 16.dp)) {
                when (tab) {
                    "Trang chủ" -> {
                        Text("Khám phá phim", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                        Text("Phim lẻ và phim bộ từ các thư viện bạn đã thêm", color = Color.LightGray)
                        Spacer(Modifier.height(12.dp))
                        FilmList(films, onSelect = { selected = it }, onPlay = { f ->
                            val url = if (f.type == "movie") f.videoUrl else f.seasons.firstOrNull()?.episodes?.firstOrNull()?.videoUrl.orEmpty()
                            if (url.isNotBlank()) onPlay(f.title, url) else selected = f
                        })
                    }
                    "Tìm kiếm" -> {
                        OutlinedTextField(query, { query = it }, Modifier.fillMaxWidth(), label = { Text("Tìm tên phim, thể loại...") }, leadingIcon = { Icon(Icons.Default.Search, null) })
                        FilmList(films.filter { it.title.contains(query, true) || it.category.contains(query, true) }, { selected = it }, { f ->
                            if (f.videoUrl.isNotBlank()) onPlay(f.title, f.videoUrl) else selected = f
                        })
                    }
                    "Yêu thích" -> FilmList(films.filter { it.id in favorites }, { selected = it }, { f -> if (f.videoUrl.isNotBlank()) onPlay(f.title, f.videoUrl) else selected = f })
                    "Nguồn" -> {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("Nguồn phim", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                            Spacer(Modifier.weight(1f))
                            Button(onClick = { showAddSource = true }) { Text("Thêm nguồn") }
                        }
                        Text("Mỗi nguồn có website để xem và địa chỉ JSON/API tùy chọn để đồng bộ thư viện.", color = Color.LightGray)
                        LazyColumn {
                            items(sources) { s ->
                                Card(Modifier.fillMaxWidth().padding(vertical = 5.dp), colors = CardDefaults.cardColors(containerColor = Panel)) {
                                    Column(Modifier.padding(12.dp)) {
                                        Text(s.name, fontWeight = FontWeight.Bold)
                                        Text(s.websiteUrl, color = Color.LightGray, style = MaterialTheme.typography.bodySmall)
                                        if (s.catalogUrl.isNotBlank()) Text("JSON: ${s.catalogUrl}", color = Color.LightGray, style = MaterialTheme.typography.bodySmall)
                                        Row {
                                            TextButton(onClick = { onOpenWebsite(s.websiteUrl) }) { Text("Mở website") }
                                            TextButton(onClick = { refreshSource(s) }) { Text("Đồng bộ") }
                                            TextButton(onClick = { sources = sources - s; saveSources() }) { Text("Xóa", color = Red) }
                                        }
                                    }
                                }
                            }
                        }
                    }
                    else -> {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("Quản lý thư viện", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                            Spacer(Modifier.weight(1f))
                            Button(onClick = { showAddFilm = true }) { Text("Thêm phim") }
                        }
                        Row {
                            OutlinedButton(onClick = { showJson = true }) { Text("Nhập JSON") }
                            Spacer(Modifier.width(8.dp))
                            OutlinedButton(onClick = { jsonText = CatalogParser.encode(films.filter { it.source == "Thủ công" }); showJson = true }) { Text("Xuất JSON") }
                        }
                        Text("Tổng ${films.size} phim/tập mục • ${films.count { it.type == "series" }} phim bộ • ${films.count { it.type != "series" }} phim lẻ", color = Color.LightGray)
                        FilmList(films, { selected = it }, { f -> if (f.videoUrl.isNotBlank()) onPlay(f.title, f.videoUrl) else selected = f })
                    }
                }
            }
        }
    }

    if (showAddSource) AlertDialog(
        onDismissRequest = { showAddSource = false },
        title = { Text("Thêm nguồn phim") },
        text = { Column {
            OutlinedTextField(sourceName, { sourceName=it }, label={Text("Tên nguồn")})
            OutlinedTextField(websiteUrl, { websiteUrl=it }, label={Text("Địa chỉ website (https://...)")})
            OutlinedTextField(catalogUrl, { catalogUrl=it }, label={Text("Địa chỉ API/JSON (không bắt buộc)")})
        }},
        confirmButton = { TextButton(onClick = {
            if (sourceName.isNotBlank() && websiteUrl.startsWith("https://")) {
                sources = sources + FilmSource(sourceName.trim(), websiteUrl.trim(), catalogUrl.trim()); saveSources()
                sourceName=""; websiteUrl=""; catalogUrl=""; showAddSource=false
            } else status = "Hãy nhập tên và website bắt đầu bằng https://"
        }) { Text("Lưu") } },
        dismissButton = { TextButton(onClick={showAddSource=false}) { Text("Hủy") } }
    )

    if (showAddFilm) AlertDialog(
        onDismissRequest = { showAddFilm=false },
        title = { Text("Thêm phim thủ công") },
        text = { Column(Modifier.heightIn(max=480.dp)) {
            OutlinedTextField(filmTitle,{filmTitle=it},label={Text("Tên phim")})
            OutlinedTextField(filmDesc,{filmDesc=it},label={Text("Mô tả")})
            OutlinedTextField(filmPoster,{filmPoster=it},label={Text("Link ảnh poster")})
            OutlinedTextField(filmCategory,{filmCategory=it},label={Text("Thể loại")})
            OutlinedTextField(filmVideo,{filmVideo=it},label={Text("Link video trực tiếp (nếu có)")})
            Text("Loại phim")
            Row(verticalAlignment=Alignment.CenterVertically) {
                RadioButton(filmType=="movie",{filmType="movie"}); Text("Phim lẻ")
                Spacer(Modifier.width(12.dp))
                RadioButton(filmType=="series",{filmType="series"}); Text("Phim bộ")
            }
            Text("Với phim bộ, nhập tập/mùa bằng JSON ở mục Nhập JSON.", color=Color.LightGray, style=MaterialTheme.typography.bodySmall)
        }},
        confirmButton = { TextButton(onClick = {
            if (filmTitle.isNotBlank()) {
                films = films + Film("manual_${System.currentTimeMillis()}",filmTitle,filmDesc,filmPoster,filmCategory,type=filmType,videoUrl=filmVideo,source="Thủ công")
                saveFilms(); filmTitle=""; filmDesc=""; filmPoster=""; filmCategory=""; filmVideo=""; showAddFilm=false
            }
        }) { Text("Lưu phim") } },
        dismissButton = { TextButton(onClick={showAddFilm=false}) { Text("Hủy") } }
    )

    if (showJson) AlertDialog(
        onDismissRequest = { showJson=false },
        title = { Text("Nhập / xuất thư viện JSON") },
        text = { Column {
            Text("Dán JSON dạng mảng phim. Nhập sẽ thay thế các mục thủ công hiện tại.", color=Color.LightGray)
            OutlinedTextField(jsonText,{jsonText=it}, modifier=Modifier.fillMaxWidth().height(250.dp), label={Text("Nội dung JSON")})
        }},
        confirmButton = { TextButton(onClick = {
            try {
                val parsed = CatalogParser.parse(jsonText,"Thủ công")
                films = films.filterNot { it.source=="Thủ công" } + parsed
                saveFilms(); status="Đã nhập ${parsed.size} phim"; showJson=false
            } catch (e: Exception) { status="JSON chưa đúng định dạng: ${e.localizedMessage}" }
        }) { Text("Nhập và lưu") } },
        dismissButton = { TextButton(onClick={showJson=false}) { Text("Đóng") } }
    )

    selected?.let { f ->
        AlertDialog(
            onDismissRequest={selected=null},
            title={Text(f.title)},
            text={
                Column(Modifier.heightIn(max=500.dp)) {
                    Text("${f.year} • ${f.category} • ${if(f.type=="series") "Phim bộ" else "Phim lẻ"}", color=Color.LightGray)
                    Spacer(Modifier.height(8.dp))
                    Text(f.description)
                    Spacer(Modifier.height(8.dp))
                    if (f.type=="movie") {
                        Button(onClick={ if(f.videoUrl.isNotBlank()) onPlay(f.title,f.videoUrl) else status="Phim chưa có link video trực tiếp" }) { Text("Phát phim") }
                    } else {
                        f.seasons.forEach { season ->
                            Text(season.title, fontWeight=FontWeight.Bold)
                            season.episodes.forEach { ep ->
                                TextButton(onClick={onPlay("${f.title} - ${ep.title}",ep.videoUrl)}) { Text("▶ ${ep.title}") }
                            }
                        }
                        if (f.seasons.isEmpty()) Text("Chưa có tập. Hãy thêm seasons/episodes trong JSON.", color=Color.LightGray)
                    }
                    TextButton(onClick={
                        favorites = if(f.id in favorites) favorites-f.id else favorites+f.id
                        prefs.edit().putStringSet("favorites",favorites).apply()
                    }) { Text(if(f.id in favorites) "♥ Bỏ yêu thích" else "♡ Thêm yêu thích") }
                }
            },
            confirmButton={TextButton(onClick={selected=null}){Text("Đóng")}}
        )
    }
}

@Composable
private fun FilmList(items: List<Film>, onSelect: (Film)->Unit, onPlay: (Film)->Unit) {
    LazyColumn(Modifier.fillMaxSize(), contentPadding=PaddingValues(vertical=8.dp)) {
        items(items, key={it.id}) { film ->
            Card(Modifier.fillMaxWidth().padding(vertical=5.dp).clickable { onSelect(film) }, colors=CardDefaults.cardColors(containerColor=Panel), shape=RoundedCornerShape(12.dp)) {
                Row(Modifier.padding(12.dp), verticalAlignment=Alignment.CenterVertically) {
                    Box(Modifier.size(width=72.dp,height=96.dp).background(Color(0xFF34343D),RoundedCornerShape(8.dp)), contentAlignment=Alignment.Center) {
                        if (film.poster.startsWith("https://")) {
                            AsyncImage(model=film.poster, contentDescription=film.title, modifier=Modifier.fillMaxSize())
                        } else {
                            Icon(Icons.Default.Movie, contentDescription=null, tint=Color.LightGray)
                        }
                    }
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(film.title, fontWeight=FontWeight.Bold)
                        Text("${if(film.type=="series") "Phim bộ" else "Phim lẻ"} • ${film.category}", color=Color.LightGray, style=MaterialTheme.typography.bodySmall)
                        Text(film.source, color=Red, style=MaterialTheme.typography.labelSmall)
                        Text(film.description, maxLines=2, color=Color.LightGray, style=MaterialTheme.typography.bodySmall)
                    }
                    IconButton(onClick={onPlay(film)}) { Icon(Icons.Default.PlayArrow, contentDescription="Phát", tint=Red) }
                }
            }
        }
        if(items.isEmpty()) item { Text("Chưa có phim. Vào Thư viện để thêm phim hoặc Nguồn để đồng bộ JSON.", color=Color.LightGray, modifier=Modifier.padding(16.dp)) }
    }
}
