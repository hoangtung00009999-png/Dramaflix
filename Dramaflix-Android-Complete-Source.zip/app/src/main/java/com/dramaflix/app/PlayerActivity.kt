package com.dramaflix.app

import android.os.Bundle
import android.view.View
import android.widget.FrameLayout
import androidx.activity.ComponentActivity
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView

class PlayerActivity : ComponentActivity() {
    private var player: ExoPlayer? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val url = intent.getStringExtra("url").orEmpty()
        title = intent.getStringExtra("title") ?: "Dramaflix Player"
        if (!url.startsWith("https://") && !url.startsWith("http://")) { finish(); return }
        val view = PlayerView(this)
        view.layoutParams = FrameLayout.LayoutParams(-1, -1)
        view.keepScreenOn = true
        setContentView(view)
        player = ExoPlayer.Builder(this).build().also {
            view.player = it
            it.setMediaItem(MediaItem.fromUri(url))
            it.prepare()
            it.playWhenReady = true
        }
    }
    override fun onStop() { super.onStop(); player?.pause() }
    override fun onDestroy() { player?.release(); player=null; super.onDestroy() }
}
