# Dramaflix Android

## Tính năng trong bản mã nguồn
- Giao diện Android tiếng Việt, nền tối và điểm nhấn đỏ.
- Danh sách nguồn website; mở website bằng WebView tích hợp.
- Đồng bộ thư viện từ URL API/JSON trả về JSON tương thích.
- Nhập/xuất thư viện JSON thủ công.
- Phim lẻ, phim bộ, mùa và tập.
- Tìm kiếm, yêu thích, trình phát video Media3.
- Thêm phim thủ công.
- GitHub Actions tạo APK debug.

## Cấu trúc JSON được hỗ trợ
Có thể là mảng JSON trực tiếp hoặc object có khóa `movies`/`films`.

Ví dụ:
```json
[
  {
    "id": "movie-001",
    "title": "Tên phim lẻ",
    "description": "Mô tả phim",
    "poster": "https://example.com/poster.jpg",
    "category": "Tình cảm",
    "year": "2026",
    "type": "movie",
    "videoUrl": "https://example.com/video.mp4"
  },
  {
    "id": "series-001",
    "title": "Tên phim bộ",
    "description": "Mô tả phim bộ",
    "poster": "https://example.com/series.jpg",
    "category": "Tâm lý",
    "year": "2026",
    "type": "series",
    "seasons": [
      {
        "title": "Mùa 1",
        "episodes": [
          { "title": "Tập 1", "videoUrl": "https://example.com/episode-1.mp4" },
          { "title": "Tập 2", "videoUrl": "https://example.com/episode-2.mp4" }
        ]
      }
    ]
  }
]
```

`videoUrl` cần là URL phát trực tiếp mà bạn có quyền sử dụng. Website thông thường không phải API JSON. Nếu website không cung cấp API/feed công khai thì thêm website chỉ giúp mở website, không tự nhập được danh sách phim.

## Build APK trên GitHub bằng điện thoại
1. Tạo repository GitHub mới tên `Dramaflix`.
2. Giải nén ZIP trên điện thoại.
3. Tải các thư mục/tệp bên trong lên repository, giữ nguyên cấu trúc và thư mục `.github/workflows`.
4. Mở tab **Actions** trong repository, chọn **Build Dramaflix APK**, bấm **Run workflow**.
5. Khi chạy xong, mở lần chạy thành công, kéo xuống **Artifacts**, tải `Dramaflix-debug-APK`.
6. Giải nén file artifact để lấy `app-debug.apk`, mở APK để cài. Nếu Android hỏi, cho phép cài ứng dụng từ nguồn này.

Lưu ý: Đây là mã nguồn dự án, chưa phải APK đã biên dịch. GitHub Actions sẽ biên dịch APK. Cần kiểm tra log Actions nếu build thất bại.
